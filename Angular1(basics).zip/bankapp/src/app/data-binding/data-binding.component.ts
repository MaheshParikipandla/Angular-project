
import { Component, OnInit } from '@angular/core';@Component({
selector: 'app-data-binding',
templateUrl: './data-binding.component.html',
styleUrls: ['./data-binding.component.css']
})
export class DataBindingComponent implements OnInit {
uname:string='hello';
city:string='bangalore';
name= 'Mahesh';
age='22';
year=1999; 
source:any="assets/index.png";
high:number=300;
wid:number=300;
src='assets/index.jpeg';
enable:boolean=true;
val:string='';
tname:string='';
constructor() { } ngOnInit(): void {
}
getDetails()
{
return`hi this is ${this.uname} and city is ${this.city}`;
}
demo(value:any)
{
  this.val=value;
}
getData()
{
return`hi this is ${this.name} and Age is ${this.age}`;
}
twoway(a:any){
  this.tname=a;
  }
}

