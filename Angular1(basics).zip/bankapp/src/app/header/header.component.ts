import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})

export class HeaderComponent implements OnInit {
  val:string='';
  val1:string='';
  val2:string='';
  interest=0.05;

  constructor() { }

  ngOnInit(): void {
  }
 
  demo(v:any,v2:any){
    this.val=`${v*v2*0.05}`;
    }
    demo1(n3:any,n4:any){
      this.val1=`${n3}`;
      }
      demo2(n5:any,n6:any,n7:any,n8:any)
      {
        this.val2=`${n6}`;
      }
}
