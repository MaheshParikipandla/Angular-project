export class User
{
    // id:number=0;
    firstname:string='';
    lastname: string='';
    email:string='';
    mobile:number=0;
    pass: string='';
    cpass: string='';
    accountType: string='';







}