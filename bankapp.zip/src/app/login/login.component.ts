import { Component, OnInit } from '@angular/core';
import { User } from '../user';
import { UserService } from '../user.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
flag:boolean=false;
mess:string='';
msg:string='';
prop:string='';
user:User=new User();
  constructor(private users :UserService) { }

  ngOnInit(): void {
  }
  changes(){
    if(this.flag){
      this.flag=!this.flag; }
    else{
        this.flag=!this.flag;
      }
}
save(obj:any)
  {
    
    this.user.email=obj.email;

    this.user.pass=obj.pass;
    
    if(this.user.email=="" && this.user.pass=="")
    {
         this.msg=`Login Successful`;
    }
    else{
      this.msg=`invalid ceredentials`;
    }

    if(this.user !== null)
   {
  this.users.saveUser(this.user).subscribe((res)=>{
  console.log(res);
  });

} 
  }

  

}
